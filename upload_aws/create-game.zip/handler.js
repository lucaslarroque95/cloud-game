"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const domain_1 = require("@game/domain");
const parser_1 = require("./parser");
const handler = async (event) => {
    const input = (0, parser_1.parseCreateGameRequest)(event.body);
    const game = domain_1.GameModel.create({
        startingPlayer: input.startingPlayer ?? "RANDOM",
        maxGameTimeSec: input.maxGameTimeSec ?? 3600,
        maxMoveTimeSec: input.maxMoveTimeSec ?? 30,
    });
    const repo = new domain_1.GameRepository("Games");
    await (0, domain_1.awsCall)(() => repo.create(game), "Error creating game");
    return {
        statusCode: 201,
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ gameId: game.gameId }),
    };
};
exports.handler = handler;
