"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const handler_1 = require("./handler");
(async () => {
    const result = await (0, handler_1.handler)({
        body: JSON.stringify({}),
    });
    console.log(result);
})();
