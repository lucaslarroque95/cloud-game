"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseCreateGameRequest = parseCreateGameRequest;
function parseCreateGameRequest(body) {
    if (!body)
        return {};
    let parsed;
    try {
        parsed = JSON.parse(body);
    }
    catch {
        throw new Error("Invalid JSON body");
    }
    if (typeof parsed !== "object" || parsed === null) {
        throw new Error("Body must be an object");
    }
    return parsed;
}
